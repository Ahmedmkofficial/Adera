import { AxiosError } from 'axios'
import { beforeEach, describe, expect, it, vi } from 'vitest'
import { SESSION_KEY } from '../auth/constants'
import { UNAUTHORIZED_EVENT } from '../services/events'

// Loads the API layer in "real backend" mode, with the network replaced by `handler`.
async function realApi(handler) {
  vi.resetModules()
  vi.stubEnv('VITE_USE_MOCK', 'false')
  const api = await import('../services/api')
  const { http } = await import('../services/http')
  const seen = []
  http.defaults.adapter = async (config) => {
    seen.push(config)
    return handler(config)
  }
  return { api, seen }
}

const reply = (config, data, status = 200) => ({ data, status, statusText: 'OK', headers: {}, config })
const failWith = (config, status) => {
  throw new AxiosError('Request failed', 'ERR_BAD_RESPONSE', config, null, {
    status,
    data: {},
    headers: {},
    config,
    statusText: '',
  })
}
const b64url = (o) => btoa(JSON.stringify(o)).replace(/=+$/, '').replace(/\+/g, '-').replace(/\//g, '_')
const jwt = (claims) => `${b64url({ alg: 'HS256' })}.${b64url(claims)}.signature`

function signedIn() {
  sessionStorage.setItem(
    SESSION_KEY,
    JSON.stringify({
      token: 'abc.def.ghi',
      user: { username: 'admin', name: 'Admin', role: 'analyst' },
      expiresAt: Date.now() + 60_000,
    }),
  )
}

describe('demo mode (the default)', () => {
  beforeEach(() => vi.resetModules())

  it('answers from the built-in demo data without any network call', async () => {
    const { checkRisk } = await import('../services/api')
    const result = await checkRisk('0912345678', 5000)
    expect(result).toMatchObject({ score: 75, level: 'CRITICAL', recommendation: 'STOP_AND_VERIFY' })
  })
})

describe('real backend mode', () => {
  it('sends the risk check to POST /risk/check', async () => {
    const answer = { score: 10, level: 'LOW', recommendation: 'ALLOW', reasons: [] }
    const { api, seen } = await realApi((c) => reply(c, answer))
    expect(await api.checkRisk('0911111111', 250)).toEqual(answer)
    expect(seen[0].method).toBe('post')
    expect(seen[0].url).toBe('/risk/check')
    expect(JSON.parse(seen[0].data)).toEqual({ recipient_phone: '0911111111', amount: 250 })
  })

  it('attaches the signed-in token to requests', async () => {
    signedIn()
    const { api, seen } = await realApi((c) => reply(c, []))
    await api.getAlerts()
    expect(seen[0].headers.Authorization).toBe('Bearer abc.def.ghi')
  })

  it('sends no token when nobody is signed in', async () => {
    const { api, seen } = await realApi((c) => reply(c, []))
    await api.getAlerts()
    expect(seen[0].headers.Authorization).toBeUndefined()
  })

  it('announces an ended session when the server answers 401', async () => {
    signedIn()
    const { api } = await realApi((c) => failWith(c, 401))
    const heard = vi.fn()
    window.addEventListener(UNAUTHORIZED_EVENT, heard)
    await expect(api.getAlerts()).rejects.toBeTruthy()
    window.removeEventListener(UNAUTHORIZED_EVENT, heard)
    expect(heard).toHaveBeenCalledTimes(1)
  })

  it('signs in with POST /auth/login using a username', async () => {
    const token = jwt({ sub: 'admin', name: 'Admin', role: 'analyst' })
    const { api, seen } = await realApi((c) => reply(c, { access_token: token }))
    await api.login('admin', 'secret-pass')
    expect(seen[0].url).toBe('/auth/login')
    expect(JSON.parse(seen[0].data)).toEqual({ username: 'admin', password: 'secret-pass' })
  })

  it('still accepts a backend that sends "phone" in the user object', async () => {
    const token = jwt({ exp: Math.floor(Date.now() / 1000) + 600 })
    const { api } = await realApi((c) =>
      reply(c, { access_token: token, user: { phone: '0911000001', name: 'Hana', role: 'customer' } }),
    )
    const session = await api.login('0911000001', 'pw-pw-pw-1')
    expect(session.user.username).toBe('0911000001')
  })

  it('does not treat a wrong password as an ended session', async () => {
    const { api } = await realApi((c) => failWith(c, 401))
    const heard = vi.fn()
    window.addEventListener(UNAUTHORIZED_EVENT, heard)
    await expect(api.login('0911000001', 'wrong')).rejects.toBeTruthy()
    window.removeEventListener(UNAUTHORIZED_EVENT, heard)
    expect(heard).not.toHaveBeenCalled()
  })

  it('turns "404 not found" into null, but still reports other failures', async () => {
    const missing = await realApi((c) => failWith(c, 404))
    expect(await missing.api.getAlert(1)).toBeNull()
    const broken = await realApi((c) => failWith(c, 500))
    await expect(broken.api.getAlert(1)).rejects.toBeTruthy()
  })

  it('keeps unusual characters out of the URL path', async () => {
    const { api, seen } = await realApi((c) => reply(c, null))
    await api.getEntity('09/12 ../x')
    expect(seen[0].url).toBe('/recipients/09%2F12%20..%2Fx')
  })

  it('reads name, role and expiry from the token when the response has no user object', async () => {
    const exp = Math.floor(Date.now() / 1000) + 600
    const token = jwt({ sub: 'selam', name: 'Selam', role: 'analyst', exp })
    const { api } = await realApi((c) => reply(c, { access_token: token, token_type: 'bearer' }))
    const session = await api.login('selam', 'pw-pw-pw-1')
    expect(session.user).toEqual({ username: 'selam', name: 'Selam', role: 'analyst' })
    expect(session.expiresAt).toBe(exp * 1000)
  })

  it('refuses a sign-in response with an unknown role', async () => {
    const token = jwt({ sub: 'selam', role: 'superuser' })
    const { api } = await realApi((c) => reply(c, { access_token: token }))
    await expect(api.login('selam', 'pw-pw-pw-1')).rejects.toThrow('Unexpected sign-in response')
  })

  it('records a decision with POST /cases/{id}/decision', async () => {
    const { api, seen } = await realApi((c) => reply(c, { id: 7, status: 'CLOSED' }))
    await api.submitDecision(7, 'FRAUD')
    expect(seen[0].url).toBe('/cases/7/decision')
    expect(JSON.parse(seen[0].data)).toEqual({ decision: 'FRAUD' })
  })

  it('opens a case with POST /cases', async () => {
    const { api, seen } = await realApi((c) => reply(c, { id: 9 }))
    await api.createCase(1042)
    expect(seen[0].url).toBe('/cases')
    expect(JSON.parse(seen[0].data)).toEqual({ alert_id: 1042 })
  })
})
