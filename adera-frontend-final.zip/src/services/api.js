// Every call the app makes to the backend goes through this file.
// With VITE_USE_MOCK unset (the default) it answers from src/mock. With
// VITE_USE_MOCK=false it calls the real FastAPI backend using the contract in
// docs/API_CONTRACT.md. Pages never know the difference.
import { decodeJwtPayload } from '../auth/session'
import { ROLES } from '../auth/constants'
import {
  mockCheckRisk,
  mockCreateCase,
  mockGetAlert,
  mockGetAlerts,
  mockGetCase,
  mockGetCases,
  mockGetDashboardSummary,
  mockGetEntity,
  mockGetGraph,
  mockSimulateTransaction,
  mockSubmitDecision,
  mockSubmitReport,
} from '../mock/mockData'
import { mockLogin, mockRegister } from '../mock/mockAuth'
import { USE_MOCK } from './config'
import { http } from './http'

// The HTTP status behind an error, from Axios or from the mock.
export const statusOf = (error) => error?.response?.status ?? error?.status

const body = (request) => request.then((response) => response.data)

// For "get one thing": a 404 means "not there", which the pages show as "not found".
const bodyOrNull = (request) =>
  request.then(
    (response) => response.data,
    (error) => (statusOf(error) === 404 ? null : Promise.reject(error)),
  )

const part = (value) => encodeURIComponent(String(value)) // safe inside a URL path

// ---------- sign in ----------
function toSession(data) {
  const token = data?.access_token
  const claims = decodeJwtPayload(token) ?? {}
  const user = data?.user ?? { username: claims.sub, name: claims.name, role: claims.role }
  const username = user?.username ?? user?.phone // older backends may still send "phone"
  if (typeof token !== 'string' || !username || !ROLES.includes(user.role)) {
    throw new Error('Unexpected sign-in response')
  }
  return {
    token,
    user: { username: String(username), name: String(user.name ?? username), role: user.role },
    expiresAt: claims.exp ? claims.exp * 1000 : undefined,
  }
}

export async function login(username, password) {
  const data = USE_MOCK
    ? await mockLogin(username, password)
    : await body(http.post('/auth/login', { username, password }))
  return toSession(data)
}

export async function register({ phone, name, password }) {
  return USE_MOCK ? mockRegister({ phone, name, password }) : body(http.post('/auth/register', { phone, name, password }))
}

// ---------- customer ----------
export async function checkRisk(recipient_phone, amount) {
  return USE_MOCK ? mockCheckRisk(recipient_phone, amount) : body(http.post('/risk/check', { recipient_phone, amount }))
}

export async function simulateTransaction(recipient_phone, amount) {
  return USE_MOCK
    ? mockSimulateTransaction(recipient_phone, amount)
    : body(http.post('/transactions/simulate', { recipient_phone, amount }))
}

export async function submitReport(report) {
  return USE_MOCK ? mockSubmitReport(report) : body(http.post('/reports', report))
}

// ---------- analyst ----------
export async function getDashboardSummary() {
  return USE_MOCK ? mockGetDashboardSummary() : body(http.get('/dashboard/summary'))
}

export async function getAlerts() {
  return USE_MOCK ? mockGetAlerts() : body(http.get('/alerts'))
}

export async function getAlert(id) {
  return USE_MOCK ? mockGetAlert(id) : bodyOrNull(http.get(`/alerts/${part(id)}`))
}

export async function getEntity(phone) {
  return USE_MOCK ? mockGetEntity(phone) : bodyOrNull(http.get(`/recipients/${part(phone)}`))
}

export async function getGraph(phone) {
  return USE_MOCK ? mockGetGraph(phone) : bodyOrNull(http.get(`/recipients/${part(phone)}/graph`))
}

export async function getCases() {
  return USE_MOCK ? mockGetCases() : body(http.get('/cases'))
}

export async function getCase(id) {
  return USE_MOCK ? mockGetCase(id) : bodyOrNull(http.get(`/cases/${part(id)}`))
}

export async function createCase(alertId) {
  return USE_MOCK ? mockCreateCase(alertId) : body(http.post('/cases', { alert_id: alertId }))
}

export async function submitDecision(id, decision) {
  return USE_MOCK
    ? mockSubmitDecision(id, decision)
    : body(http.post(`/cases/${part(id)}/decision`, { decision }))
}
