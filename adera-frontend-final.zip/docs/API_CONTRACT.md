# API contract (what the frontend expects)

Send this file to the backend team. Items marked **(PDF)** come from the project plan; items marked **(proposed)** are what the screens need and must be agreed with the backend owners.

General rules:

- JSON in, JSON out. Base URL from `VITE_API_URL`.
- Signed-in requests carry `Authorization: Bearer <token>`.
- Status codes the frontend understands: `401` = not signed in or session ended, `403` = signed in but not allowed, `404` = not found (shown as "not found" pages), `409` = already exists, `422` = invalid input.
- Scores are whole numbers 0 to 100. Levels: `LOW` 0-24, `MODERATE` 25-49, `HIGH` 50-74, `CRITICAL` 75-100.
- Recommendations: `ALLOW`, `REVIEW`, `VERIFY`, `STOP_AND_VERIFY`.
- Alerts are created for `MODERATE` and above (proposed).
- Roles: `customer`, `analyst`. **Analyst-only endpoints must reject customers with 403.**

## Authentication

| Call | Body | Response |
|---|---|---|
| `POST /auth/register` **(PDF)** | `{phone, name, password}` | `201` with `{phone, name, role}`. `409` if the phone exists. New accounts are always `customer`. |
| `POST /auth/login` **(PDF)** | `{username, password}`. `username` is a phone number for customers or a username for staff (lower-case). | `{access_token, token_type, user: {username, name, role}}`. `401` with one generic message for a wrong name or wrong password. *(Changed from `phone` so staff can sign in with a username. The frontend also accepts `phone` in `user` from an older backend.)* |

If `user` is missing, the frontend reads `sub` (the username), `name`, `role` and `exp` from the token's claims. `exp` is used only to end the screen session on time; the server must check it too.

## Customer

| Call | Body | Response |
|---|---|---|
| `POST /risk/check` **(PDF)** | `{recipient_phone, amount}` | `{score, level, recommendation, reasons: [string]}` |
| `POST /transactions/simulate` **(PDF)** | `{recipient_phone, amount}` | `{id, status: "SIMULATED", created_at}`. The receipt shows `TXN-<id>`. |
| `POST /reports` **(PDF)** | `{recipient_phone, scam_type, description}` | `201`. `scam_type` is one of `Impersonation`, `Fake investment`, `Prize or lottery`, `Other`: confirm the list with the threat-intelligence owner. `description` is 10 to 500 characters; **the backend must enforce this too.** |

## Analyst (all require role `analyst`)

| Call | Response |
|---|---|
| `GET /dashboard/summary` *(proposed)* | `{alerts, critical, high, open_cases, reports}` |
| `GET /alerts` **(PDF)** | `[{id, recipient_phone, score, level, reason, status, created_at}]`. `status` is `OPEN`, `IN_CASE` or `CLOSED`. Suggest paging. |
| `GET /alerts/{id}` **(PDF)** | `{id, recipient_phone, score, level, status, created_at, recommendation, reasons: [string], transactions: [{id, created_at, counterparty, amount}], reports: [{id, created_at, scam_type, summary}], reports_total, related_accounts: [{phone, relation, level}], case_id \| null}`. `counterparty` is the **sender**. `404` if unknown. |
| `GET /recipients/{phone}` **(PDF)** | `{phone, score, level, recommendation, reasons, reports_count, recent_reports, scam_cases, related_accounts_count, first_observed, last_activity, transactions, reports, reports_total, related_accounts, risk_history: [{date, score}], cases: [{id, status}]}`. `404` if no intelligence. This exposes other people's reports: **analysts only.** |
| `GET /recipients/{phone}/graph` *(proposed)* | `{phone, reports_total, nodes: [...], edges: [{id, source, target, type}]}`. Node kinds: `subject`, `account` (`id, phone, level, score, report_count, last_activity`), `report` (`id, report_id, created_at, scam_type, summary`). Edge types: `SHARED_PHONE`, `TRANSACTION`, `REPORT`. `404` if unknown. |
| `GET /cases` **(PDF)** | `[{id, alert_id, subject, score, level, status, decision \| null, updated_at}]`. `status` is `OPEN` or `CLOSED`. |
| `GET /cases/{id}` **(PDF)** | `{id, alert_id, subject, score, level, recommendation, status, decision, decided_by, decided_at, created_at, updated_at, events: [{time, title, body}], evidence: {reports, recent, scam_cases, related_accounts}, payment: {amount, txn_id, created_at}}`. `404` if unknown. |
| `POST /cases` **(PDF)** | body `{alert_id}` returns `{id, alert_id, subject, status: "OPEN", risk_level}`. |
| `POST /cases/{id}/decision` **(PDF)** | body `{decision}` where decision is `FRAUD`, `FALSE_POSITIVE` or `NEEDS_MORE_INFORMATION`. Returns the updated case. |

### Decision rules the screens assume

- `FRAUD` and `FALSE_POSITIVE` **close** the case (`status: CLOSED`) and the alert (`CLOSED`). A closed case must reject further decisions (e.g. `409`).
- `NEEDS_MORE_INFORMATION` keeps the case `OPEN` and may be followed by a final decision.
- The server records who decided and when (`decided_by`, `decided_at`) from the token. The client never sends them.

## Open questions for the team

1. What does "recent" mean for `recent_reports` (how many days)?
2. What is the shared value behind a `SHARED_PHONE` relationship? The graph can show it if it is returned.
3. Is `scam_cases` (a count on the profile) the same data as the profile's `cases` list?
4. Do `transactions[].counterparty` always mean the sender?
